from io import open

from setuptools import setup, find_packages

from extension_maker import __version__ as version

setup(
    name="extension-maker",
    version=version,
    description="Easily create browser extensions/add-ons for browsers like Chrome, Firefox, or Edge.",
    keywords=["gui", "executable"],
    packages= find_packages(),
    include_package_data=True,
    install_requires=["tk>=0.1.0","image>=1.5.33","requests"],

)
