
from . import ui


def run():
    """Module entry point"""
    ui.root.mainloop()

if __name__ == "__main__":
    run()



# def get_permissions(manifest_version):
#     return config.BROWSER_MANIFEST_VERSION_3_PERMISSIONS



                


    














